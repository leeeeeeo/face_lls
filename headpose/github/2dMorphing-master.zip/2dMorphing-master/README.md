2dMorphing
==========

2D Image Morphing Algorithms based on mesh warping.

C++ project, which is transplanted from the c codes given by Yurong Sun and George Wolberg.

Details: http://davis.wpi.edu/~matt/courses/morph/2d.htm
